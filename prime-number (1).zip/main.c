#include <stdio.h>
int Prime(int n) {
    if (n < 2) return 0;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0)
            return 0;
    }
    return 1;
}

int main() {
    int m, n;
    printf("Enter the values of m,n:\n");
    scanf("%d %d", &m, &n);
    int a[m][n];
    printf("Enter 2D Array elements:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &a[i][j]);
        }
    }
    int count = 0;
    printf("The no of PRIME numbers in a 2D array is:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if (Prime(a[i][j])) {
                count++;
            }
        }
    }

    printf("%d", count);

    return 0;
}